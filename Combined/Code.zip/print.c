#include <stdio.h>
void printDec ( unsigned val ) { printf ("%u\n", val); } 